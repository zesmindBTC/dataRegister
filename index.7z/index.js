var http = require('http');
var BTCE = require('./btc-e.js');
var mongo = require('mongodb');
var url = require('url');

var mongoClient = require('mongodb').MongoClient;


var MONGOHQ_URL="mongodb://localhost:27017/Base_depth4";
//var MONGOHQ_URL="mongodb://nodejitsu:48f2fd6a825d2a273f58cffadab0d66d@linus.mongohq.com:10083/nodejitsudb3969138751";

mongoClient.connect(MONGOHQ_URL, function(error, db) {
	"use strict";

		(function(){
		var btcePublic = new BTCE();

		db.collection('trades', function(err,collection){
		collection.ensureIndex({'tid':1}, function(){})
		});


		var dbDepth = btcePublic.depth("btc_usd", function(err, data) {
				if (!err) {
					try{
						db.collection('depth', function(err,collection){
							collection.insert(data, function(){});	
						});
					}
					catch (err) {

						}
				}

				});


		var dbTrades = btcePublic.trades("btc_usd", function(err, data) {
							if (!err) {	
								try{
									data.forEach(function(a){
										db.collection('trades', function(err,collection){
											if (!err) { 
												collection.findOne({'tid':a.tid}, function(err, result) {
														if (!err) { 
															if (!result) {
																collection.insert(a, function(){});
															} else {
																//console.log('SI HAY, tid:' + a.tid);
															}
														}
													});
												}
										});
									 });
								}
							catch (err) {

								}
							}
						});

		var dbTicker = btcePublic.ticker("btc_usd", function(err, data) {
				if (!err) {
					try{
						db.collection('ticker', function(err,collection){
							collection.insert(data, function(){});	
						});
					}
					catch (err) {

						}
				}

				});

		setInterval(function () {
			dbDepth;
			dbTrades;
			dbTicker;
		},5000)})();
});